#!/bin/bash
cd ./
mkdir packages
cd packages
git clone https://github.com/rodolphe37/cra-template-github-my-profile.git
cd ..
echo -e "\e[96mENTER THE APP NAME HERE \e[97m(my-example-name) ?"
read string
npx create-react-app ${string} --template file:./packages/cra-template-github-my-profile
rm -rf packages
