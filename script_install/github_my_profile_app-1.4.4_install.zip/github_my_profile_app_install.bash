#!/bin/bash
color='\e[96m' #cyan color
rose='\e[1;31m'
vertfonce='\e[0;32m'
orange='\e[0;33m'
bleuclair='\e[1;34m'
blanc='\e[1;37m'
BAR='##################################################'   # this is full bar, e.g. 50 chars

loader(){
  for i in {1..50}; do
    echo -ne "\r${BAR:0:$i}" # print $i chars of $BAR from 0 position
    sleep $1                # wait 100ms (.1 - slow velocity) or 10ms (.01 - false velocity) between "frames"
  done
echo ""                        # add a new line at the end
}

timer(){
    echo $SECONDS
}
# begin of  automatic install process
echo ""
echo -e "${color}\xf0\x9f\x98\xba\xf0\x9f\x98\x80 Hello $USER, The installation procedure will begin... \xf0\x9f\x98\xba\xf0\x9f\x98\x80${vertfonce}"
echo ""
# loader slow velocity
loader .1;
# Always start from current folder
cd ./
echo ""
echo -e "${color} Create temporary folder ${vertfonce}"
mkdir packages
cd packages
# loader slow velocity
loader .01;
echo ""
echo -e "${color} Clone repo to temporary folder ${vertfonce}"
git clone https://github.com/rodolphe37/cra-template-github-my-profile.git
cd ..
# loader slow velocity
loader .01;
echo ""
echo -e "${color} Create App with --template option ${vertfonce}"
# loader slow velocity
loader .01;
echo -e "\e[96mENTER THE APP NAME HERE \e[97m(my-example-name) ?"
read string
npx create-react-app ${string} --template file:./packages/cra-template-github-my-profile
# loader slow velocity
loader .01;
echo ""
echo -e "${color} Remove temporary folder ${vertfonce}"
rm -rf packages
cd ${string};
while true; do
    echo ""
    read -p " Do you want personalize your App now?" yn
    case $yn in
        [Yy]* )  ./github_my_profile_personalization.sh; exit;; # else exit from script
        [Nn]* )  break;;
        * ) echo " Please answer Yes or No";;
    esac
done
