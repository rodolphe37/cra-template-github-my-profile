#!/bin/bash
mkdir packages
cd packages
git clone https://github.com/rodolphe37/cra-template-github-my-profile.git
cd ..
echo "enter-the-app-name ?"
read string
npx create-react-app ${string} --template file:./packages/cra-template-github-my-profile
rm -rf packages
